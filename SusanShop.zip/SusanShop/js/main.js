// Lấy dữ liệu từ JSON Server
fetch("http://localhost:3000/products")
  .then(response => response.json())
  .then(data => {
    const productList = document.getElementById("product-list");
    productList.innerHTML = data.map(p => `
      <div class="product">
        <a href="product.html?id=${p.id}">
          <img src="${p.image}" alt="${p.name}">
          <h3>${p.name}</h3>
          <p>${p.detail}</p>
          <p><b>${p.price.toLocaleString()}₫</b></p>
        </a>
      </div>
    `).join("");
  })
  .catch(err => console.error("Lỗi khi load sản phẩm:", err));
