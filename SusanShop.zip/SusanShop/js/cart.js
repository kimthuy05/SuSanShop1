// Lấy giỏ hàng từ localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

const tbody = document.querySelector("#cart-table tbody");
const totalEl = document.getElementById("total");

function renderCart() {
  if (cart.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6">Giỏ hàng trống!</td></tr>`;
    totalEl.textContent = "0₫";
    return;
  }

  let total = 0;

  tbody.innerHTML = cart.map((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    return `
      <tr>
        <td><img src="${item.image}" width="80"></td>
        <td>${item.name}</td>
        <td>${item.price.toLocaleString()}₫</td>
        <td>
          <button class="qty-btn" onclick="updateQty(${index}, -1)">-</button>
          ${item.quantity}
          <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
        </td>
        <td>${itemTotal.toLocaleString()}₫</td>
        <td><button onclick="removeItem(${index})">Xóa</button></td>
      </tr>
    `;
  }).join("");

  totalEl.textContent = total.toLocaleString() + "₫";
}

function updateQty(index, change) {
  cart[index].quantity += change;
  if (cart[index].quantity <= 0) {
    if (confirm("Bạn có muốn xóa sản phẩm này không?")) {
      cart.splice(index, 1);
    } else {
      cart[index].quantity = 1;
    }
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

function removeItem(index) {
  if (confirm("Bạn có chắc muốn xóa sản phẩm này?")) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
  }
}

// Nút thanh toán
document.getElementById("checkout").addEventListener("click", () => {
  if (cart.length === 0) {
    alert("Giỏ hàng trống!");
    return;
  }
  window.location.href = "checkout.html";
});

renderCart();
