// Lấy id sản phẩm từ URL
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

if (!id) {
  document.getElementById("product-detail").innerHTML = "<p>Không tìm thấy sản phẩm!</p>";
} else {
  fetch(`http://localhost:3000/products/${id}`)
    .then(res => {
      if (!res.ok) throw new Error("Không thể tải sản phẩm!");
      return res.json();
    })
    .then(p => {
      document.getElementById("product-detail").innerHTML = `
        <div class="product-detail">
          <img src="${p.image}" alt="${p.name}">
          <div>
            <h2>${p.name}</h2>
            <p>${p.description}</p>
            <h3>${p.price.toLocaleString()}₫</h3>
            <button id="add-to-cart">Thêm vào giỏ hàng</button>
          </div>
        </div>
      `;

      // Xử lý thêm vào giỏ hàng
      document.getElementById("add-to-cart").addEventListener("click", () => {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        const exist = cart.find(item => item.id === p.id);
        if (exist) exist.quantity++;
        else cart.push({ ...p, quantity: 1 });
        localStorage.setItem("cart", JSON.stringify(cart));
        alert("Đã thêm sản phẩm vào giỏ hàng!");
      });
    })
    .catch(err => {
      document.getElementById("product-detail").innerHTML = `<p>${err.message}</p>`;
    });
}
