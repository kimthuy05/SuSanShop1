// Lấy giỏ hàng từ localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

const tbody = document.querySelector("#order-table tbody");
const totalEl = document.getElementById("total");

// Hiển thị danh sách sản phẩm
function renderOrder() {
  if (cart.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4">Giỏ hàng trống!</td></tr>`;
    totalEl.textContent = "0₫";
    return;
  }

  let total = 0;
  tbody.innerHTML = cart.map(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    return `
      <tr>
        <td>${item.name}</td>
        <td>${item.price.toLocaleString()}₫</td>
        <td>${item.quantity}</td>
        <td>${itemTotal.toLocaleString()}₫</td>
      </tr>
    `;
  }).join("");
  totalEl.textContent = total.toLocaleString() + "₫";
}
renderOrder();

// Xử lý sự kiện khi người dùng nhấn "Xác nhận thanh toán"
document.getElementById("checkout-form").addEventListener("submit", (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const address = document.getElementById("address").value.trim();

  if (!name || !email || !phone || !address) {
    alert("Vui lòng nhập đầy đủ thông tin!");
    return;
  }

  // Mô phỏng lưu đơn hàng vào JSON Server
  const order = {
    id: Date.now(),
    user: { name, email, phone, address },
    items: cart,
    total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    created_date: new Date().toLocaleString(),
    status: "Đã thanh toán"
  };

  // Gửi dữ liệu order tới db.json (nếu có cấu hình endpoint /orders)
  fetch("http://localhost:3000/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(order)
  })
  .then(res => res.json())
  .then(() => {
    // Xóa giỏ hàng sau khi thanh toán
    localStorage.removeItem("cart");
    // Chuyển đến trang cảm ơn
    window.location.href = "thankyou.html";
  })
  .catch(err => {
    console.error("Lỗi khi lưu đơn hàng:", err);
    alert("Thanh toán không thành công, vui lòng thử lại!");
  });
});
