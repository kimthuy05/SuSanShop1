const ORDER_API = "http://localhost:3000/orders";
const DETAIL_API = "http://localhost:3000/order_details";
const PRODUCT_API = "http://localhost:3000/products";

Promise.all([
  fetch(ORDER_API).then(res => res.json()),
  fetch(DETAIL_API).then(res => res.json()),
  fetch(PRODUCT_API).then(res => res.json())
]).then(([orders, details, products]) => {
  // Tổng doanh thu
  const revenue = details.reduce((sum, d) => sum + d.unit_price * d.quantity, 0);
  document.getElementById("revenue").innerText = revenue.toLocaleString() + "₫";

  // Tổng đơn hàng
  document.getElementById("totalOrders").innerText = orders.length;

  // Tổng sản phẩm
  document.getElementById("totalProducts").innerText = products.length;

  // Sản phẩm bán chạy
  const countByProduct = {};
  details.forEach(d => {
    countByProduct[d.product_id] = (countByProduct[d.product_id] || 0) + d.quantity;
  });

  const bestSellers = Object.entries(countByProduct)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const ul = document.getElementById("best-seller");
  bestSellers.forEach(([productId, qty]) => {
    const product = products.find(p => p.id == productId);
    ul.innerHTML += `<li>${product?.name || "Không rõ"} - ${qty} sản phẩm</li>`;
  });
});
