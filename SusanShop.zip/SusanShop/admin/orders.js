const ORDER_API = "http://localhost:3000/orders";
const DETAIL_API = "http://localhost:3000/order_details";

const orderTable = document.querySelector("#order-table tbody");
const detailContainer = document.getElementById("detail-container");
const detailTable = document.querySelector("#order-detail-table tbody");

// Hiển thị danh sách đơn hàng
fetch(ORDER_API)
  .then(res => res.json())
  .then(data => renderOrders(data));

function renderOrders(orders) {
  orderTable.innerHTML = orders.map(o => `
    <tr>
      <td>${o.id}</td>
      <td>${o.user_id}</td>
      <td>${o.created_date}</td>
      <td>
        <select onchange="updateStatus(${o.id}, this.value)">
          <option value="Chờ xử lý" ${o.status === "Chờ xử lý" ? "selected" : ""}>Chờ xử lý</option>
          <option value="Đã giao" ${o.status === "Đã giao" ? "selected" : ""}>Đã giao</option>
          <option value="Đã hủy" ${o.status === "Đã hủy" ? "selected" : ""}>Đã hủy</option>
        </select>
      </td>
      <td><button onclick="showDetail(${o.id})">Xem chi tiết</button></td>
    </tr>
  `).join("");
}

// Cập nhật trạng thái
function updateStatus(id, newStatus) {
  fetch(`${ORDER_API}/${id}`, {
    method: "PATCH",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ status: newStatus })
  });
}

// Xem chi tiết
function showDetail(orderId) {
  fetch(`${DETAIL_API}?order_id=${orderId}`)
    .then(res => res.json())
    .then(details => {
      detailTable.innerHTML = details.map(d => `
        <tr>
          <td>${d.product_id}</td>
          <td>${d.quantity}</td>
          <td>${d.unit_price.toLocaleString()}₫</td>
        </tr>
      `).join("");
      detailContainer.style.display = "block";
    });
}

function closeDetail() {
  detailContainer.style.display = "none";
}
