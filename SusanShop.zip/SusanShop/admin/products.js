// Load danh sách sản phẩm từ JSON Server
fetch("http://localhost:3000/products")
  .then(res => res.json())
  .then(products => {
    const table = document.getElementById("product-table");
    table.innerHTML = products.map(p => `
      <tr>
        <td>${p.id}</td>
        <td>${p.name}</td>
        <td>${p.price.toLocaleString()}₫</td>
        <td><img src="${p.image}" width="80"></td>
        <td>${p.detail}</td>
        <td>
          <button onclick="deleteProduct(${p.id})">🗑️ Xóa</button>
        </td>
      </tr>
    `).join("");
  });

// Hàm xóa sản phẩm
function deleteProduct(id) {
  if (confirm("Bạn có chắc muốn xóa sản phẩm này?")) {
    fetch(`http://localhost:3000/products/${id}`, { method: "DELETE" })
      .then(res => {
        if (res.ok) {
          alert("Đã xóa sản phẩm!");
          location.reload();
        }
      });
  }
}
