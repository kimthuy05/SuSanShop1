const USER_API = "http://localhost:3000/users";
const userTable = document.querySelector("#user-table tbody");

fetch(USER_API)
  .then(res => res.json())
  .then(data => renderUsers(data));

function renderUsers(users) {
  userTable.innerHTML = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td>${u.phone}</td>
      <td>${u.address}</td>
      <td>
        <button onclick="deleteUser(${u.id})">Xóa</button>
      </td>
    </tr>
  `).join("");
}

function deleteUser(id) {
  if (confirm("Bạn có chắc muốn xóa khách hàng này?")) {
    fetch(`${USER_API}/${id}`, { method: "DELETE" })
      .then(() => location.reload());
  }
}
